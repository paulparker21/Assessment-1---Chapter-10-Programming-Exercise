﻿namespace Assessment_1___Chapter_10_Programming_Exercise
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pinFolbl = new System.Windows.Forms.Label();
            this.nameLbl = new System.Windows.Forms.Label();
            this.mnumLbl = new System.Windows.Forms.Label();
            this.emailLbl = new System.Windows.Forms.Label();
            this.addLbl = new System.Windows.Forms.Label();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.numberTxt = new System.Windows.Forms.TextBox();
            this.emailTxt = new System.Windows.Forms.TextBox();
            this.addTxt = new System.Windows.Forms.TextBox();
            this.upBtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.displayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enterName = new System.Windows.Forms.Label();
            this.enterNumber = new System.Windows.Forms.Label();
            this.enterEmail = new System.Windows.Forms.Label();
            this.enterAddress = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            //
            // pinFolbl
            //
            this.pinFolbl.AutoSize = true;
            this.pinFolbl.Location = new System.Drawing.Point(102, 58);
            this.pinFolbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pinFolbl.Name = "pinFolbl";
            this.pinFolbl.Size = new System.Drawing.Size(103, 13);
            this.pinFolbl.TabIndex = 0;
            this.pinFolbl.Text = "Personal Information";
            //
            // nameLbl
            //
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(67, 88);
            this.nameLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(35, 13);
            this.nameLbl.TabIndex = 1;
            this.nameLbl.Text = "Name";
            //
            // mnumLbl
            //
            this.mnumLbl.AutoSize = true;
            this.mnumLbl.Location = new System.Drawing.Point(67, 110);
            this.mnumLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mnumLbl.Name = "mnumLbl";
            this.mnumLbl.Size = new System.Drawing.Size(78, 13);
            this.mnumLbl.TabIndex = 2;
            this.mnumLbl.Text = "Phone Number";
            //
            // emailLbl
            //
            this.emailLbl.AutoSize = true;
            this.emailLbl.Location = new System.Drawing.Point(68, 133);
            this.emailLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.emailLbl.Name = "emailLbl";
            this.emailLbl.Size = new System.Drawing.Size(32, 13);
            this.emailLbl.TabIndex = 3;
            this.emailLbl.Text = "Email";
            //
            // addLbl
            //
            this.addLbl.AutoSize = true;
            this.addLbl.Location = new System.Drawing.Point(68, 154);
            this.addLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.addLbl.Name = "addLbl";
            this.addLbl.Size = new System.Drawing.Size(45, 13);
            this.addLbl.TabIndex = 4;
            this.addLbl.Text = "Address";
            //
            // nameTxt
            //
            this.nameTxt.Location = new System.Drawing.Point(160, 81);
            this.nameTxt.Margin = new System.Windows.Forms.Padding(2);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.Size = new System.Drawing.Size(76, 20);
            this.nameTxt.TabIndex = 5;
            //
            // numberTxt
            //
            this.numberTxt.Location = new System.Drawing.Point(160, 104);
            this.numberTxt.Margin = new System.Windows.Forms.Padding(2);
            this.numberTxt.Name = "numberTxt";
            this.numberTxt.Size = new System.Drawing.Size(76, 20);
            this.numberTxt.TabIndex = 6;
            //
            // emailTxt
            //
            this.emailTxt.Location = new System.Drawing.Point(160, 127);
            this.emailTxt.Margin = new System.Windows.Forms.Padding(2);
            this.emailTxt.Name = "emailTxt";
            this.emailTxt.Size = new System.Drawing.Size(76, 20);
            this.emailTxt.TabIndex = 7;
            //
            // addTxt
            //
            this.addTxt.Location = new System.Drawing.Point(160, 150);
            this.addTxt.Margin = new System.Windows.Forms.Padding(2);
            this.addTxt.Name = "addTxt";
            this.addTxt.Size = new System.Drawing.Size(76, 20);
            this.addTxt.TabIndex = 8;
            //
            // upBtn
            //
            this.upBtn.Location = new System.Drawing.Point(125, 186);
            this.upBtn.Margin = new System.Windows.Forms.Padding(2);
            this.upBtn.Name = "upBtn";
            this.upBtn.Size = new System.Drawing.Size(56, 23);
            this.upBtn.TabIndex = 9;
            this.upBtn.Text = "Update";
            this.upBtn.UseVisualStyleBackColor = true;
            this.upBtn.Click += new System.EventHandler(this.upBtn_Click);
            //
            // menuStrip1
            //
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.displayToolStripMenuItem,
            this.clearToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(373, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            //
            // fileToolStripMenuItem
            //
            this.displayToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.displayToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.displayToolStripMenuItem.Text = "Display";
            this.displayToolStripMenuItem.Click += new System.EventHandler(this.displayToolStripMenuItem_Click);
            //
            // clearToolStripMenuItem
            //
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            //
            // aboutToolStripMenuItem
            //
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            //
            // exitToolStripMenuItem
            //
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            //
            // enterName
            //
            this.enterName.AutoSize = true;
            this.enterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.enterName.Location = new System.Drawing.Point(239, 84);
            this.enterName.Name = "enterName";
            this.enterName.Size = new System.Drawing.Size(113, 13);
            this.enterName.TabIndex = 11;
            this.enterName.Text = "Enter a valid name";
            //
            // enterNumber
            //
            this.enterNumber.AutoSize = true;
            this.enterNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterNumber.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.enterNumber.Location = new System.Drawing.Point(239, 107);
            this.enterNumber.Name = "enterNumber";
            this.enterNumber.Size = new System.Drawing.Size(124, 13);
            this.enterNumber.TabIndex = 12;
            this.enterNumber.Text = "Enter a valid number";
            //
            // enterEmail
            //
            this.enterEmail.AutoSize = true;
            this.enterEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterEmail.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.enterEmail.Location = new System.Drawing.Point(239, 131);
            this.enterEmail.Name = "enterEmail";
            this.enterEmail.Size = new System.Drawing.Size(112, 13);
            this.enterEmail.TabIndex = 13;
            this.enterEmail.Text = "Enter a valid email";
            //
            // enterAddress
            //
            this.enterAddress.AutoSize = true;
            this.enterAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterAddress.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.enterAddress.Location = new System.Drawing.Point(239, 153);
            this.enterAddress.Name = "enterAddress";
            this.enterAddress.Size = new System.Drawing.Size(127, 13);
            this.enterAddress.TabIndex = 14;
            this.enterAddress.Text = "Enter a valid address";
            //
            // Form1
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(373, 245);
            this.Controls.Add(this.enterAddress);
            this.Controls.Add(this.enterEmail);
            this.Controls.Add(this.enterNumber);
            this.Controls.Add(this.enterName);
            this.Controls.Add(this.upBtn);
            this.Controls.Add(this.addTxt);
            this.Controls.Add(this.emailTxt);
            this.Controls.Add(this.numberTxt);
            this.Controls.Add(this.nameTxt);
            this.Controls.Add(this.addLbl);
            this.Controls.Add(this.emailLbl);
            this.Controls.Add(this.mnumLbl);
            this.Controls.Add(this.nameLbl);
            this.Controls.Add(this.pinFolbl);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label pinFolbl;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label mnumLbl;
        private System.Windows.Forms.Label emailLbl;
        private System.Windows.Forms.Label addLbl;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.TextBox numberTxt;
        private System.Windows.Forms.TextBox emailTxt;
        private System.Windows.Forms.TextBox addTxt;
        private System.Windows.Forms.Button upBtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem displayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label enterName;
        private System.Windows.Forms.Label enterNumber;
        private System.Windows.Forms.Label enterEmail;
        private System.Windows.Forms.Label enterAddress;
    }
}